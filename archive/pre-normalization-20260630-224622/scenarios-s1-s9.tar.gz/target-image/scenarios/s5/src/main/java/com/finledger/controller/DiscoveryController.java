package com.finledger.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class DiscoveryController {

    @GetMapping("/")
    public ResponseEntity<?> home() {
        return ResponseEntity.ok(Map.of(
                "service", "FinLedger",
                "summary", "Financial ledger operations for transaction review, reporting, and account support.",
                "navigation", List.of("/status", "/help", "/about", "/api", "/health")
        ));
    }

    @GetMapping("/status")
    public ResponseEntity<?> status() {
        return ResponseEntity.ok(Map.of(
                "service", "FinLedger",
                "status", "online",
                "components", List.of(
                        Map.of("name", "api", "state", "available"),
                        Map.of("name", "database", "state", "available"),
                        Map.of("name", "reporting", "state", "available")
                )
        ));
    }

    @GetMapping("/help")
    public ResponseEntity<?> help() {
        return ResponseEntity.ok(Map.of(
                "service", "FinLedger support",
                "summary", "Use authenticated API access for ledger workflows and role-appropriate reporting.",
                "gettingStarted", List.of(
                        "Authenticate before requesting account-specific resources.",
                        "Ledger entries can be listed and searched by authorized staff.",
                        "Operational reports may require elevated staff roles."
                ),
                "supportChannels", List.of("finance operations", "platform support", "audit desk")
        ));
    }

    @GetMapping("/about")
    public ResponseEntity<?> about() {
        return ResponseEntity.ok(Map.of(
                "name", "FinLedger",
                "purpose", "Internal finance service for reviewing ledger entries and executive summaries.",
                "audience", List.of("analysts", "finance operators", "administrators"),
                "dataClasses", List.of("ledger entries", "account summaries", "report metadata")
        ));
    }

    @GetMapping("/api")
    public ResponseEntity<?> api() {
        return ResponseEntity.ok(Map.of(
                "service", "FinLedger API discovery",
                "version", "2024.1",
                "publicEndpoints", List.of(
                        Map.of("method", "GET", "path", "/", "description", "service landing payload"),
                        Map.of("method", "GET", "path", "/health", "description", "basic uptime check"),
                        Map.of("method", "GET", "path", "/status", "description", "component status summary"),
                        Map.of("method", "GET", "path", "/help", "description", "operator support overview"),
                        Map.of("method", "GET", "path", "/about", "description", "service metadata")
                ),
                "serviceAreas", List.of(
                        Map.of("name", "authentication", "access", "basic credentials required for account resources"),
                        Map.of("name", "ledger", "access", "authenticated staff workflows"),
                        Map.of("name", "reports", "access", "role-sensitive business reporting"),
                        Map.of("name", "operations", "access", "platform-owned monitoring and maintenance")
                )
        ));
    }
}
