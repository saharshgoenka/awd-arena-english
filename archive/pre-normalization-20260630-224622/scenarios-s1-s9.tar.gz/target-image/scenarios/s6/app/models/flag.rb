class Flag < ApplicationRecord
end
